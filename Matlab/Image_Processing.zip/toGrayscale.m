function [output] = toGrayscale(image)

im_size=size(image);

output=zeros(im_size(1),im_size(2),'uint8');

output(:,:)=image(:,:,1).*0.3+image(:,:,1).*0.59+image(:,:,1).*0.11;

end


